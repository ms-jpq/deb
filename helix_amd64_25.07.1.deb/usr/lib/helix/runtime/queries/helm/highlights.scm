; inherits: gotmpl
